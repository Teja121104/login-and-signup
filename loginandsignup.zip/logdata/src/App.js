import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './styles/LoginForm.css';  // Import the CSS for LoginForm
import './styles/SignupForm.css'; // Import the CSS for SignupForm
import LoginForm from './components/LoginForm';   // Correct import for LoginForm component
import SignupForm from './components/SignupForm'; // Correct import for SignupForm component

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginForm />} />
        <Route path="/signup" element={<SignupForm />} />
      </Routes>
    </Router>
  );
}

export default App;
