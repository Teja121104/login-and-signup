import React from 'react';
import ReactDOM from 'react-dom';
import './styles/LoginForm.css';  // Import LoginForm styles globally if required
import './styles/SignupForm.css'; // Import SignupForm styles globally if required
import App from './App';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
