import React, { useState } from 'react';

function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    console.log('Login Attempt:', { email, password });
  };

  return (
    <section>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <div className="signin">
        <div className="content">
          <h2>Login</h2>
          <form className="form" onSubmit={handleLogin}>
            <div className="inputBox">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <i>Email</i>
            </div>
            <div className="inputBox">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <i>Password</i>
            </div>
            <div className="links">
              <a href="#">Forgot Password?</a>
              <a href="/signup">Sign Up</a>
            </div>
            <div className="inputBox">
              <input type="submit" value="Login" />
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}

export default LoginForm;
