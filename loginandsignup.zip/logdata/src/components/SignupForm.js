import React, { useState } from 'react';

function SignupForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mobile, setMobile] = useState('');
  const [state, setState] = useState('');

  const handleSignup = (e) => {
    e.preventDefault();
    console.log('Signup Attempt:', { name, email, password, mobile, state });
  };

  return (
    <section>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <div className="signin">
        <div className="content">
          <h2>Sign Up</h2>
          <form className="form" onSubmit={handleSignup}>
            <div className="inputBox">
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <i>Name</i>
            </div>
            <div className="inputBox">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <i>Email</i>
            </div>
            <div className="inputBox">
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <i>Password</i>
            </div>
            <div className="inputBox">
              <input
                type="text"
                required
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
              />
              <i>Mobile Number</i>
            </div>
            <div className="inputBox">
              <input
                type="text"
                required
                value={state}
                onChange={(e) => setState(e.target.value)}
              />
              <i>State</i>
            </div>
            <div className="links">
              <a href="#">Already have an account?</a>
              <a href="/">Login</a>
            </div>
            <div className="inputBox">
              <input type="submit" value="Sign Up" />
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}

export default SignupForm;
